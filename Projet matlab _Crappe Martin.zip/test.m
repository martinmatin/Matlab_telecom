tb = [2 2 3 3 4 4];
f = [1 2 3 4]
N = 4;
v = f;
for i = 1:N
   v = [v;f]
end
