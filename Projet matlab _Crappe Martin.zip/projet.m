%Projet Matlab Crappe Martin 



% Canal fr�quentiel = bande de fr�quence d�termin�e sur le canal partag�
clear all;

parametre;

setup;

emetteur;