% Ensemble des variables d�pendantes des param�tres caract�risant le canal

% == EMETTEUR == 


